#ifndef SOURCE_BREATHFIRSTSEARCH_H
#define SOURCE_BREATHFIRSTSEARCH_H

#include "../../Graph.h"


class BreathFirstSearch {
public:
    void run(Graph &g, Vertex *source);
};


#endif //SOURCE_BREATHFIRSTSEARCH_H
