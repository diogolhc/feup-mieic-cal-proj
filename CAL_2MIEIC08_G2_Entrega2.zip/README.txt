O projeto utiliza a ferramenta GraphViewerCPP e que, por simplicidade, já vai incluída na pasta src. 
Para compilar o programa, o utilizador basta importar os ficheiros da pasta src para o clion e dar build.

Os input files estão em src/maps e contêm informação acerca dos centros de distribuição e aplicação e dos grafos de Espinho, Porto e Penafiel
e respetivas componentes fortemente conexas.
